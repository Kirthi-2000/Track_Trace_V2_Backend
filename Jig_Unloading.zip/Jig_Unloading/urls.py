from django.urls import path
from .views import *

urlpatterns = [
    path('Jig_Unloading_PickTable/', Jig_Unloading_PickTable.as_view(), name='Jig_Unloading_PickTable'),
]